import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {


        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald", 1925, 1, "FIC FIT", true, 101));
        books.add(new Book(2, "1984", "George Orwell", 1949, 1, "FIC ORW", true, 102));
        books.add(new Book(3, "To Kill a Mockingbird", "Harper Lee", 1960, 2, "FIC LEE", false, 101));
        books.add(new Book(4, "Pride and Prejudice", "Jane Austen", 1813, 3, "FIC AUS", true, 101));
        books.add(new Book(5, "The Catcher in the Rye", "J.D. Salinger", 1951, 1, "FIC SAL", true, 102));
        books.add(new Book(6, "The Hobbit", "J.R.R. Tolkien", 1937, 1, "FIC TOL", true, 101));
        books.add(new Book(7, "The Great Gatsby", "Herman Melville", 1851, 1, "FIC MEL", true, 101));
        books.add(new Book(8, "War and Peace", "Leo Tolstoy", 1869, 1, "FIC TOL", true, 102));
        books.add(new Book(9, "The Odyssey", "Homer", 8, 1, "FIC HOM", true, 102));
        books.add(new Book(10, "The Divine Comedy", "Dante Alighieri", 1320, 1, "FIC DAN", true, 102));

        List<Library> libraries = new ArrayList<>();
        libraries.add(new Library(101, "Library 1", "Address 101 street", books));
        libraries.add(new Library(102, "Library 2", "Address 102 street", books));


        libraries.getFirst().printBooks();

        Book book1 = libraries.getFirst().borrowBook("The Great Gatsby");
        Book book2 = libraries.getFirst().borrowBook("The Great Gatsby");

        libraries.getFirst().printBooks();

        Book book3 = new Book(7, "The Great Gatsby", "Herman Melville", 1851, 1, "FIC MEL", true, 105);
        libraries.getFirst().returnBook(book1);
        libraries.getFirst().returnBook(book2);


        libraries.getFirst().printBooks();
    }
}