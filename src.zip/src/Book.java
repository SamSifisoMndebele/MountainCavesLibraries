public class Book {
    private int bookId;
    private String title;
    private String author;
    private int year;
    private int edition;
    private String callNumber;
    private boolean available;
    private int libraryId;

    public int getLibraryId() {
        return libraryId;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public Book(int bookId, String title, String author, int year, int edition, String callNumber, boolean available, int libraryId) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.year = year;
        this.edition = edition;
        this.callNumber = callNumber;
        this.available = available;
        this.libraryId = libraryId;
    }
}
